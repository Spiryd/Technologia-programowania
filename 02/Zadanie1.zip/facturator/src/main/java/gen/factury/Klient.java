package gen.factury;
//odpowiada za przechowanie informacji o klijencie
public class Klient
{
    int nip;
    String nazwa;

    Klient(int nip, String nazwa){
        this.nip = nip;
        this.nazwa = nazwa;
    }
}
