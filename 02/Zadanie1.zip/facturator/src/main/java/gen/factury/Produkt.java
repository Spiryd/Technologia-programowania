package gen.factury;
//odpowiada za przechowanie informacji o produkcie
public class Produkt {
    String nazwa;
    int cena;
    Produkt(String nazwa, int cena){
        this.nazwa = nazwa;
        this.cena = cena;
    }
}
