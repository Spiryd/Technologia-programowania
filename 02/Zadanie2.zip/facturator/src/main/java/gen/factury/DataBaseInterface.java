package gen.factury;

//interface do implementacji różnych baz danych
public interface DataBaseInterface {
    void dodajDoBazy(Faktura faktura);
}
