package gen.factury;
// odpowiada za komunikacje z daną bazą
public class DataMenager1 implements DataBaseInterface
{
    @Override
    public void dodajDoBazy(Faktura faktura) {
        //dodoje do bazy
    }
}
